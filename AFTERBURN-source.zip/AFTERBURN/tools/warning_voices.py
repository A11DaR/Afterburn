"""Render the original English cockpit voice with FFmpeg's CMU SLT voice."""
from pathlib import Path
import subprocess
import tempfile

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt


RATE = 22050
OUTPUT = Path(__file__).resolve().parents[1] / 'dist' / 'art' / 'voice'
PHRASES = {
    'pull-up': ('Pull up!', 2),
    'missile': ('Missile!', 2),
    'engine': ('Fire in engine!', 2),
    'aoa': ('A. O. A.', 2),
    'speed': ('Low airspeed!', 1),
    'flares': ('Flares empty!', 1),
    'sink': ('Sink rate!', 2),
    'six': ('Check six!', 1),
    'hull': ('Hull critical!', 1),
    'overspeed': ('Over speed!', 1),
    'rockets': ('Missiles empty!', 1),
    'ammo': ('Gun ammo low!', 1),
    'over-g': ('Over gee!', 2),
    'stall': ('Stall!', 2),
}


def render(phrase):
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt') as text:
        text.write(phrase)
        text.flush()
        command = ['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i',
                   f'flite=voice=slt:textfile={text.name}', '-ar', str(RATE),
                   '-ac', '1', '-f', 'f32le', 'pipe:1']
        raw = np.frombuffer(subprocess.check_output(command), dtype='<f4')
    sounding = np.flatnonzero(np.abs(raw) > .004)
    start = max(0, sounding[0] - int(.020 * RATE))
    end = sounding[-1] + int(.040 * RATE)
    band = butter(3, [170, 5300], btype='bandpass', fs=RATE, output='sos')
    samples = sosfilt(band, raw[start:end])
    samples = np.tanh(samples * (.19 / np.sqrt(np.mean(samples ** 2))))
    samples *= .88 / np.max(np.abs(samples))
    return samples


if __name__ == '__main__':
    OUTPUT.mkdir(parents=True, exist_ok=True)
    pause = np.zeros(round(.16 * RATE))
    for name, (phrase, repeats) in PHRASES.items():
        clip = render(phrase)
        if repeats == 2:
            clip = np.concatenate((clip, pause, clip * .96))
        wavfile.write(OUTPUT / (name + '.wav'), RATE, np.round(clip * 32767).astype('<i2'))
